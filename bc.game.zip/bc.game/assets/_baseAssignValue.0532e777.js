import{cg as a}from"./index.28e31dff.js";function o(r,e,t){e=="__proto__"&&a?a(r,e,{configurable:!0,enumerable:!0,value:t,writable:!0}):r[e]=t}export{o as b};
