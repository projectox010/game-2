import{H as e}from"./HelpPage.5a10ddbc.js";import{a}from"./index.28e31dff.js";var n=`<section>
  <p>
    You have a question? Can't find the answer on the website? Don't worry! you
    can contact our 24-hour online customer support any time, Our customer
    <a href="https://help.bc.game/en/" target="_blank" rel="noopener noreferrer" className="cl-primary">
      support
    </a>
    team is happy to answer any of your questions.
  </p>
</section>
`,r=`<section>\r
  <p>Voc\xEA est\xE1 com d\xFAvidas ou precisa de ajuda?  N\xE3o encontrou a resposta no site? N\xE3o se preocupe! Voc\xEA pode entrar em contato com nosso suporte ao cliente on-line 24 horas por dia, 7 dias por semana. Nossa equipe de  <a href="https://help.bc.game/en/" target="_blank" rel="noopener noreferrer" class="cl-primary">suporte ao cliente</a> ter\xE1 prazer em responder a qualquer uma de suas perguntas.</p>\r
</section>`,o=`<section>
  <p>
    Anda memiliki pertanyaan? Tidak dapat menemukan jawaban di website? Jangan khawatir! Anda
     dapat menghubungi dukungan pelanggan online 24 jam kami setiap saat, Pelanggan kami
    <a href="https://help.bc.game/en/" target="_blank" rel="noopener noreferrer" className="cl-primary">
      support
    </a>
    tim dengan senang hati menjawab setiap pertanyaan Anda.
  </p>
</section>
`;function p(){return a(e,{br:r,en:n,id:o,isSuport:!0})}export{p as default};
