import{H as a}from"./HelpPage.5a10ddbc.js";import{a as n}from"./index.28e31dff.js";var e=`<section>
  <h2>Why do you need a Withdraw fee?</h2>
  <p>
    When we make a transaction, the information is broadcast to the network, and
    the miners collect and package the production blocks, and only after the
    block is produced, the transaction is recognized. Although the miners will
    get a fixed monetary reward after digging into the block, according to the
    rules, the reward will gradually be halved and become less and less, and
    eventually the miners may not be profitable. Therefore, transaction fees are
    needed to maintain the enthusiasm of miners for mining.
  </p>
</section>

<section>
  <h2>The role of the Withdraw fee</h2>
  <p>1. Encourage miners to mine</p>
  <p>
    2. Prevent excessive small transactions from hitting the network. Due to the
    P2P network, the ability of transaction processing is limited. If everyone
    frequently conducts small transactions, the network will be congested,
    causing delays or even stagnation. So set a threshold, the amount of natural
    transactions will be reduced when there is a small transaction.
  </p>
</section>

<section>
  <h2>How much is the Withdraw fee?</h2>
  <p>
    Since the transaction is a two-way charge, it means that the sale of a
    digital currency requires at least a 0.1% Withdraw fee to the platform.
  </p>
</section>
`,r=`<section>\r
  <h2>Por que voc\xEA precisa de uma taxa de saque?</h2>\r
  <p>\r
   Quando fazemos uma transa\xE7\xE3o, a informa\xE7\xE3o \xE9 transmitida para a rede, e os mineradores coletam e empacotam os blocos de produ\xE7\xE3o, e somente ap\xF3s a produ\xE7\xE3o do bloco, a transa\xE7\xE3o \xE9 reconhecida. Embora os mineradores recebam uma recompensa monet\xE1ria fixa depois de cavar o bloco, de acordo com as regras, a recompensa ser\xE1 gradualmente reduzida pela metade e se tornar\xE1 cada vez menor e, eventualmente, os mineradores podem n\xE3o ser lucrativos. Portanto, as taxas de transa\xE7\xE3o s\xE3o necess\xE1rias para manter o entusiasmo dos mineradores pela minera\xE7\xE3o.\r
  </p>\r
</section>\r
\r
<section>\r
  <h2>O papel da taxa de saque</h2>\r
  <p>1. Incentive os mineradores a minerar</p>\r
  <p>\r
   2. Evite que pequenas transa\xE7\xF5es excessivas atinjam a rede. Devido \xE0 rede P2P, a capacidade de processamento de transa\xE7\xF5es \xE9 limitada. Se todos realizarem pequenas transa\xE7\xF5es com frequ\xEAncia, a rede ficar\xE1 congestionada, causando atrasos ou at\xE9 estagna\xE7\xE3o. Portanto, defina um limite, a quantidade de transa\xE7\xF5es naturais ser\xE1 reduzida quando houver uma pequena transa\xE7\xE3o.\r
  </p>\r
</section>\r
\r
<section>\r
  <h2>Quanto \xE9 a taxa de saque?</h2>\r
  <p>\r
    Como a transa\xE7\xE3o \xE9 uma cobran\xE7a bidirecional, isso significa que a venda de uma moeda digital exige pelo menos uma taxa de saque de 0,1% para a plataforma.</p>\r
</section>`,t=`<section>
  <h2>Mengapa Anda perlu biaya Penarikan?</h2>
  <p>
    Saat kami melakukan transaksi, informasi tersebut disiarkan ke jaringan, dan
     para penambang mengumpulkan dan mengemas blok produksi, dan hanya setelah
     blok diproduksi, transaksi diakui. Meskipun para penambang akan
     dapatkan hadiah uang tetap setelah menggali ke dalam blok, sesuai dengan
     aturan, hadiahnya secara bertahap akan dibelah dua dan menjadi semakin berkurang, dan
     akhirnya para penambang mungkin tidak menguntungkan. Oleh karena itu, biaya transaksi 
     diperlukan untuk menjaga semangat para penambang untuk menambang.
  </p>
</section>

<section>
  <h2>Peran biaya Penarikan</h2>
  <p>1. 1. Dorong para penambang untuk menambang</p>
  <p>
    2. Mencegah transaksi kecil yang berlebihan dari memukul jaringan. Karena
     Pada jaringan P2P, kemampuan pemrosesan transaksi terbatas. Jika semua orang
     sering melakukan transaksi kecil, jaringan akan padat,
     menyebabkan keterlambatan atau bahkan stagnasi. Jadi tetapkan ambang batas, jumlah yang alami
     transaksi akan berkurang bila terjadi transaksi kecil.
  </p>
</section>

<section>
  <h2>Berapa biaya Penarikan?</h2>
  <p>
    Karena transaksi adalah biaya dua arah, itu berarti bahwa penjualan
     mata uang digital memerlukan setidaknya biaya Penarikan 0,1% ke platform.
  </p>
</section>
`;function o(){return n(a,{br:r,en:e,id:t})}export{o as default};
