import{H as a}from"./HelpPage.5a10ddbc.js";import{a as e}from"./index.28e31dff.js";var n=`<section>
  <h2>BCSwap Policy</h2>
  <p>
    BC.GAME has a strict anti-money laundering policy. This is in accordance
    with our AML procedures outlined in our terms of service.
  </p>
  <p>
    If deposits & withdrawals are suspected of being attempts to Swap coins we
    reserve the right to hold withdrawals until completion of one of the
    following procedures
  </p>
  <p>
    1. Withdrawal is sent after full completion of account verification & KYC
  </p>
  <p>2. Withdrawal refunded & 1x gameplay is reached.</p>
  <p>
    BCSwap will always try to ensure every matter is resolved & the above can be
    modified to suit specific situations.
  </p>
</section>
`,i=`<section>
  <h2>BCPol\xEDtica de Swap</h2>
     <p>
       BC.GAME tem uma pol\xEDtica r\xEDgida de combate \xE0 lavagem de dinheiro. Isso est\xE1 de acordo com nossos procedimentos AML descritos em nossos termos de servi\xE7o.
     </p>
     <p>
       Se houver suspeita de dep\xF3sitos e saques como tentativas de trocar moedas, nos reservamos o direito de reter saques at\xE9 a conclus\xE3o de um dos seguintes procedimentos
     </p>
     <p>
       1. A retirada \xE9 enviada ap\xF3s a conclus\xE3o completa da verifica\xE7\xE3o da conta e KYC
     </p>
     <p>2. A retirada foi reembolsada e o jogo 1x foi alcan\xE7ado.</p>
     <p>
       BCSwap sempre tentar\xE1 garantir que todos os assuntos sejam resolvidos e que o acima possa ser modificado para se adequar a situa\xE7\xF5es espec\xEDficas.
     </p>
  </section>`,s=`<section>
  <h2>BCKebijakan Tukar</h2>
   <p>
     BC.GAME memiliki kebijakan anti pencucian uang yang ketat. Ini sesuai dengan prosedur AML kami yang diuraikan dalam persyaratan layanan kami.
   </p>
   <p>
     Jika penyetoran & penarikan dicurigai sebagai upaya untuk menukar koin, kami berhak menahan penarikan hingga selesainya salah satu prosedur berikut
   </p>
   <p>
     1. Penarikan dikirim setelah selesainya verifikasi akun & KYC
   </p>
   <p>2. Penarikan dikembalikan & 1x gameplay tercapai.</p>
   <p>
     BCSwap akan selalu berusaha memastikan setiap masalah diselesaikan & hal di atas dapat dimodifikasi agar sesuai dengan situasi tertentu.
  </p>
</section>
`;function r(){return e(a,{br:i,en:n,id:s})}export{r as default};
