import{H as a}from"./HelpPage.5a10ddbc.js";import{a as e}from"./index.28e31dff.js";var n=`<section>
    <h2>Company Business Model</h2>
    <p>BC.GAME is operated by BlockDance B.V. (Commercial register of Cura\xE7ao no.158182, Emancipatie Boulevard Dominico F. "Don" Martina 31, Cura\xE7ao) under a sublicense CIL pursuant to Master gaming License #5536/JAZ.Company Policy Statement. BlockDance B.V. falls within the scope of the AML obligations according to Curacao legislations. Therefore, the senior management has implemented systems and procedures that meet the standards set forth by relevant AML legislation in Curacao.</p>
    <h2>Definitions ML</h2>
    <p>Money Laundering: The process of making illegally gained proceeds appear legal. This process is generally broken down into three steps: placement, layering, and integration. Placement: The process of placing unlawful proceeds into traditional financial institutions, through deposits or other avenues. Layering:  The process of separating proceeds of criminal activity from their origin by layers of complex financial transactions, such as converting cash into traveler\u2019s checks, money orders, wire transfers, letters of credit, stocks, bonds, or purchasing assets. Integration:  Using legitimate transactions to disguise the illicit proceeds, allowing the laundered funds to be distributed back to the criminal; integrating the now clean money back into normal use.</p>
    <h2>AML (Anti-Money Laundering) policy</h2>
    <p>BlockDance B.V. is aware that offering services related to online gaming pose a risk for money laundering and terrorist financing. To identify, prevent, and limit the risks of money laundering and terrorist financing. BlockDance B.V. implemented measures, processes, and internal controls into its daily business operations, which consider the nature of the BlockDance B.V.\u2019s clients and services carried out by BlockDance B.V. With these measures, processes, and internal controls in place BlockDance B.V. meets all legal requirements related to measures preventing money laundering and terrorist financing, as required by applicable Curacao legislations. BlockDance B.V. has prepared AML Policy regarding the prevention of money laundering to prove its commitment for detection, prevention, and reporting to national authorities of all attempts of using BlockDance B.V.\u2019s services for any kind of transaction which would meet the statutory definition of money laundering and/or terrorist financing, or which presents any other form of illegal financial transactions.
        AML Policy is modified and upgraded by changing legislation and good practice in the industry. The content of the AML Policy covers:</p>
    <ul>
        <li>the internal organization of processes related to prevention of money laundering;</li>
        <li>due diligence process (also known as \u201CKnow your customer or KYC\u201D)</li>
        <li>money laundering risk assessment;</li>
        <li>non-eligible and eligible categories of clients;</li>
        <li>enhanced due diligence measures; </li>
        <li>reporting obligations (towards competent authorities).  </li>
    </ul>
</section>`,i=`<section>\r
  <h2>Modelo de Neg\xF3cios da Empresa</h2>\r
    <p>BC.GAME \xE9 operado pela BlockDance B.V. (Registro Comercial de Cura\xE7ao no.158182, Emancipatie Boulevard Dominico F. "Don" Martina 31, Cura\xE7ao) sob uma sublicen\xE7a CIL de acordo com a Master gaming License #5536/JAZ.Declara\xE7\xE3o de pol\xEDtica da empresa. BlockDance B.V. est\xE1 dentro do escopo das obriga\xE7\xF5es AML de acordo com as legisla\xE7\xF5es de Cura\xE7ao. Portanto, a alta administra\xE7\xE3o implementou sistemas e procedimentos que atendem aos padr\xF5es estabelecidos pela legisla\xE7\xE3o AML relevante em Cura\xE7ao.</p>\r
    <h2>Lavagem de Dinheiro</h2>\r
    <p>Lavagem de dinheiro: O processo de fazer com que os lucros obtidos ilegalmente pare\xE7am legais. Esse processo geralmente \xE9 dividido em tr\xEAs etapas: coloca\xE7\xE3o, camadas e integra\xE7\xE3o. Coloca\xE7\xE3o: O processo de coloca\xE7\xE3o de recursos il\xEDcitos em institui\xE7\xF5es financeiras tradicionais, por meio de dep\xF3sitos ou outras vias. Camadas: O processo de separar o produto da atividade criminosa de sua origem por camadas de transa\xE7\xF5es financeiras complexas, como a convers\xE3o de dinheiro em cheques de viagem, ordens de pagamento, transfer\xEAncias eletr\xF4nicas, cartas de cr\xE9dito, a\xE7\xF5es, t\xEDtulos ou compra de ativos. Integra\xE7\xE3o: Usar transa\xE7\xF5es leg\xEDtimas para disfar\xE7ar os rendimentos il\xEDcitos, permitindo que os fundos lavados sejam distribu\xEDdos de volta ao criminoso; integrando o dinheiro agora limpo de volta ao uso normal.</p>\r
    <h2> Pol\xEDtica de Preven\xE7\xE3o e Combate \xE0 Lavagem de Dinheiro</h2>\r
    <p>A BlockDance B.V. est\xE1 ciente de que a oferta de servi\xE7os relacionados a jogos online representa um risco de lavagem de dinheiro e financiamento do terrorismo. Identificar, prevenir e limitar os riscos de lavagem de dinheiro e financiamento do terrorismo. A BlockDance B.V. implementou medidas, processos e controles internos em suas opera\xE7\xF5es comerciais di\xE1rias, que consideram a natureza dos clientes e servi\xE7os da BlockDance B.V. realizados pela BlockDance B.V. Com essas medidas, processos e controles internos em vigor, a BlockDance B.V. atende a todos os requisitos legais requisitos relacionados \xE0s medidas de preven\xE7\xE3o \xE0 lavagem de dinheiro e ao financiamento do terrorismo, conforme exigido pelas legisla\xE7\xF5es aplic\xE1veis \u200B\u200Bde Cura\xE7ao. A BlockDance B.V. preparou a Pol\xEDtica AML referente \xE0 preven\xE7\xE3o de lavagem de dinheiro para provar seu compromisso com a detec\xE7\xE3o, preven\xE7\xE3o e comunica\xE7\xE3o \xE0s autoridades nacionais de todas as tentativas de usar os servi\xE7os da BlockDance B.V. para qualquer tipo de transa\xE7\xE3o que atenda \xE0 defini\xE7\xE3o estatut\xE1ria de lavagem de dinheiro e/ou financiamento do terrorismo, ou que apresente qualquer outra forma de transa\xE7\xF5es financeiras ilegais.\r
        A Pol\xEDtica AML \xE9 modificada e atualizada por meio de mudan\xE7as na legisla\xE7\xE3o e boas pr\xE1ticas do setor. O conte\xFAdo da Pol\xEDtica AML abrange:</p>\r
    <ul>\r
        <li>a organiza\xE7\xE3o interna dos processos relacionados \xE0 preven\xE7\xE3o \xE0 lavagem de dinheiro;</li>\r
        <li>processo de due diligence (tamb\xE9m conhecido como "Conhe\xE7a seu cliente ou KYC")</li>\r
        <li>avalia\xE7\xE3o de risco de lavagem de dinheiro;</li>\r
        <li>categorias de clientes eleg\xEDveis e n\xE3o qualificados;</li>\r
        <li>medidas de due diligence refor\xE7adas; </li>\r
        <li>obriga\xE7\xF5es de comunica\xE7\xE3o (para as autoridades competentes). </li>\r
    </ul>\r
</section>`,o=`<section>
    <h2>Model Bisnis Perusahaan</h2>

  <p>BC.GAME dioperasikan oleh BlockDance B.V. (Daftar komersial Cura\xE7ao no.158182, Emancipatie Boulevard Dominico F. "Don" Martina 31, Cura\xE7ao) di bawah CIL sublisensi sesuai dengan Master gaming License #5536/JAZ.Pernyataan Kebijakan Perusahaan. BlockDance B.V. termasuk dalam cakupan kewajiban AML menurut undang-undang Curacao. Oleh karena itu, manajemen senior telah menerapkan sistem dan prosedur yang memenuhi standar yang ditetapkan oleh undang-undang AML yang relevan di Curacao.</p>

<h2>Penjelasan ML (Money Laundering)</h2>
<p>Money Laundering atau Pencucian Uang: Proses membuat hasil yang diperoleh secara ilegal tampak legal.Proses ini umumnya dipecah menjadi tiga langkah: penempatan, pelapisan, dan intergrasi.Penempatan: Proses menempatkan hasil yang melanggar hukum ke dalam lembaga keuangan tradisional, melalui deposito atau cara lain.Layering: Proses memisahkan hasil kegiatan kriminal dari asalnya dengan lapisan transaksi keuangan yang kompleks, seperti mengubah uang tunai menjadi cek perjalanan, wesel, transfer kawat, surat kredit, saham, obligasi, atau pembelian aset.Integrasi: Menggunakan transaksi yang sah untuk menyamarkan hasil haram, memungkinkan dana yang dicuci untuk didistribusikan kembali ke penjahat;mengintegrasikan uang yang sudah bersih kembali ke penggunaan normal.</p>
    
<h2>Kebijakan AML (Anti Pencucian Uang)</h2>
BlockDance B.V. menyadari bahwa menawarkan layanan yang terkait dengan game online menimbulkan risiko pencucian uang dan pendanaan teroris. Untuk mengidentifikasi, mencegah, dan membatasi risiko pencucian uang dan pendanaan teroris. BlockDance B.V. menerapkan langkah-langkah, proses, dan kontrol internal ke dalam operasi bisnis hariannya, yang mempertimbangkan sifat klien dan layanan BlockDance B.V. yang dilakukan oleh BlockDance B.V. Dengan langkah-langkah, proses, dan kontrol internal ini, BlockDance B.V. memenuhi semua hukum persyaratan yang terkait dengan tindakan pencegahan pencucian uang dan pendanaan teroris, sebagaimana disyaratkan oleh undang-undang Curacao yang berlaku. BlockDance B.V. telah menyiapkan Kebijakan AML mengenai pencegahan pencucian uang untuk membuktikan komitmennya untuk mendeteksi, mencegah, dan melaporkan kepada otoritas nasional dari semua upaya penggunaan layanan BlockDance B.V. untuk segala jenis transaksi yang akan memenuhi definisi undang-undang tentang pencucian uang dan/atau pendanaan teroris, atau yang menyajikan bentuk lain dari transaksi keuangan ilegal.Kebijakan AML dimodifikasi dan ditingkatkan dengan mengubah undang-undang dan praktik yang baik di industri.
<ul>
Isi dari Kebijakan AML meliputi:
<li>organisasi internal proses yang terkait dengan pencegahan pencucian uang;</li>
        <li>proses uji tuntas (juga dikenal sebagai "Kenali pelanggan Anda atau KYC")</li>
        <li>penilaian risiko pencucian uang;</li>
        <li>kategori klien yang tidak memenuhi syarat dan memenuhi syarat;</li>
        <li>langkah-langkah uji tuntas yang ditingkatkan;</li>
        <li>kewajiban pelaporan (kepada pihak yang berwenang).</li>
</section>`;function t(){return e(a,{br:i,en:n,id:o})}export{t as default};
