import{H as a}from"./HelpPage.5a10ddbc.js";import{a as e}from"./index.28e31dff.js";var n=`<section>
  <h2>What is cryptocurrency?</h2>
  <p>
    Cryptocurrency is a digital currency that does not rely on any real
    substance and makes use of cryptography, eg. Bitcoin, litcoin, BitShares,
    etc. It is a digital currency that is created, distributed, and maintained
    based on cryptography and validation technology. The characteristics of
    cryptocurrency are its application of P2P technology and the fact that
    everyone issues it.
  </p>
  <p>
    Cryptocurrency is also an online payment system that supports anonymous
    transcommon.actions. Bitcoin is the top cryptocurrency, and is recognised by
    the laws in many countries.
  </p>
</section>

<section>
  <h2>Why using cryptocurrency?</h2>
  <p>
    Due to several reasons, crytocurrency is the most popular and widely used
    digital currency. In contrast to traditional transfer, We transfers never
    require several hours of waiting, and are not affected by the transfer
    amount or the region of the user. The fee is also much lower, and is usually
    a few cents. Refund will not happen to cryptocurrency, and no cheating is
    possible. No bank, government agency, or individual could manipulate
    cryptocurrency. In contrast to traditional currency, cryptocurrency
    transactions are anonymous, and there is no threat of confiscation.
  </p>
</section>

<section>
  <h2>How does cryptocurrency transaction work?</h2>
  <p>
    Cryptocurrency transactions are actually very simple. Basically it is to
    send cryptocurrency from an online wallet to another. The first step in the
    whole process is that the payer sends a private key (a randomly generated
    sequence of numbers) to the payee, after which a transaction will go through
    0 to 5 validations. An ordinary transaction will go through 1 validation,
    but if the amount is very large, it is better to perform multiple
    validations. It takes about 10 minutes for a single validation on the
    blockchain network. After validation, anyone on the blockchain can check
    this transaction but could not see any sensitive information.
  </p>
</section>

<section>
  <h2>How to purchase cryptocurrency?</h2>
  <p>Cryptocurrency can be purchased at the following places:</p>
  <p>
    Market exchange: If the buyer does not care much about privacy, then an
    online market exchange is the best option to buy cryptocurrency because
    market exchanges usually require the buyers to provide identification.
    Buyers could purchase cryptocurrency from a market exchange and store it
    there.
  </p>
  <p>
    Over the counter: This means two people perform a cryptocurrency transaction
    face-to-face. Usually cryptocurrency transactions are carried out
    anonymously between the two parties. Although the face-to-face approach does
    not enjoy this benefit, it is still very popular. Sellers and buyers could
    contact each other through many websites.
  </p>
  <p>
    Cryptocurrency ATM: These ATM are no different from normal ATM apart from
    that the buyer gets a receipt with a certain code instead of cash. By
    scanning the code, the bitcoin will be transferred to the buyer\u2019s wallet.
  </p>
</section>

<section>
  <h2>Is cryptocurrency legal?</h2>
  <p>
    Simply put, the legal status of cryptocurrency is getting better. In the
    past few months, Japan announced to recognise bitcoin as a legal currency,
    and Russia also declared its plan to recognise bitcoin as a financial tool.
    This is a major change of stance for Russia, since bitcoin was originally
    banned in Russia.
  </p>
  <p>
    While cryptocurrency gradually becomes a strong and important global
    currency, this kind of change will also increase. The regulation on, use of,
    and taxation on cryptocurrency still vary across countries. On the other
    hand, new laws and rules are published all the time. If you wish to know in
    details about your government\u2019s stance on cryptocurrency and potential
    changes in the future, please contact a legal consultant.
  </p>
</section>

<section>
  <h2>Bitcoin wallet</h2>
  <p>
    There are many bitcoin wallet available. There are cloud-based wallets as
    well as wallets that can be downloaded to personal computers, tablet
    computers, or mobile phones. You can also get a physical hardware wallet
    that stores cryptocurrency. There is a common function among the various
    wallets, which is to transfer cryptocurrency, but each wallet has its own
    merit.
  </p>
</section>

<section>
  <h2>Cloud-based wallet</h2>
  <p>
    Cloud-based wallet is the easiest and most convenient to use wallet.
    However, storing cryptocurrency in the cloud means handing over the
    responsibility of storing to the company that safekeeps your cryptocurrency.
    Therefore, mutual trust between the two parties is vital in storing
    cryptocurrency in a cloud-based wallet.
  </p>
  <p>We recommend the following cloud-based wallet:</p>
  <ul>
    <li>
      <p>
        <a href="https://copay.io/" target="_blank" rel="noopener noreferrer"> copay.io </a>
      </p>
    </li>
    <li>
      <p>
        <a href="https://www.bitgo.com/" target="_blank" rel="noopener noreferrer"> bitgo.com </a>
      </p>
    </li>
  </ul>
</section>

<section>
  <h2>Software wallet</h2>
  <p>
    A software wallet is a downloadable program that can be run on computers,
    tablet computers, or mobile phones. A software wallet is safer than a
    cloud-based one because you can take full control of it. However, a software
    wallet still has its risks.
  </p>
  <p>We recommend the following software wallets:</p>
  <ul>
    <li>
      <p>
        <a href="https://copay.io/" target="_blank" rel="noopener noreferrer"> copay.io </a>
      </p>
    </li>
    <li>
      <p>
        <a href="https://breadapp.com/" target="_blank" rel="noopener noreferrer"> Breadwallet </a>
      </p>
    </li>
    <li>
      <p>
        <a href="https://www.mycelium.com/" target="_blank" rel="noopener noreferrer"> Mycelium </a>
      </p>
    </li>
  </ul>
</section>

<section>
  <h2>Hardware Wallet</h2>
  <p>
    A hardware wallet stores the user\u2019s private key in a secure hardware device.
    Compared to software wallets, one of the main advantages of hardware wallets
    is immunity against computer virus. Moreover, since the private key is
    stored in the protected zone of a microcontroller, it cannot be transferred
    out of the device in cleartext.
  </p>
  <p>We recommend the following hardware wallets:</p>
  <ul>
    <li>
      <p>
        <a href="https://trezor.io/" target="_blank" rel="noopener noreferrer"> Trezor </a>
      </p>
    </li>
    <li>
      <p>
        <a href="https://www.ledgerwallet.com/" target="_blank" rel="noopener noreferrer"> Ledger </a>
      </p>
    </li>
  </ul>
  <p>To know more about various bitcoin wallets, please visit Bitcoin.org.</p>
</section>

<section>
  <h2>Protect your wallet</h2>
  <p>
    When used properly, bitcoin is highly secure. Please always remember it is
    your responsibility to take measures to protect your money.
  </p>
  <p>You should consider the following points:</p>
  <p>Like legal tender, do not put all your money in one wallet.</p>
  <p>Choose your online wallet carefully. 2FA is a good extra guarantee.</p>
  <p>
    Back up your wallet regularly. It is also a good practice to encrypt backups
    that are exposed to the Internet.
  </p>
  <p>
    Store the password in a secure location. You may memorise your password, or
    store it in a secure physical location.
  </p>
  <p>
    Choose a strong password that contains letters, numbers, and symbols, and is
    at least 16 characters long.
  </p>
  <p>
    Offline wallet, also known as cold storage, provides the highest security
    for your deposit. It is to hide the wallet in a secure place that is not
    connected to the Internet. If implemented well, this option could provide
    excellent protection against computer vulnerabilities.
  </p>
</section>
`,t=`<section>\r
  <h2>O que \xE9 criptomoeda?</h2>\r
  <p>A criptomoeda \xE9 uma moeda digital que n\xE3o depende de nenhuma subst\xE2ncia real e faz uso de criptografia, por exemplo. Bitcoin, litcoin, BitShares, etc. \xC9 uma moeda digital que \xE9 criada, distribu\xEDda e mantida com base em tecnologia de criptografia e valida\xE7\xE3o. As caracter\xEDsticas da criptomoeda s\xE3o a aplica\xE7\xE3o da tecnologia P2P e o fato de que todos a emitem.</p>\r
  <p>A criptomoeda tamb\xE9m \xE9 um sistema de pagamento online que suporta transcommon.actions an\xF4nimos. Bitcoin \xE9 a principal criptomoeda e \xE9 reconhecida pelas leis em muitos pa\xEDses.</p>\r
  <h2>Por que usar criptomoeda?</h2>\r
  <p>Devido a v\xE1rias raz\xF5es, a criptomoeda \xE9 a moeda digital mais popular e amplamente utilizada. Ao contr\xE1rio da transfer\xEAncia tradicional, as transfer\xEAncias da We nunca exigem v\xE1rias horas de espera e n\xE3o s\xE3o afetadas pelo valor da transfer\xEAncia ou pela regi\xE3o do usu\xE1rio. A taxa tamb\xE9m \xE9 muito menor e geralmente \xE9 de alguns centavos. O reembolso n\xE3o acontecer\xE1 com a criptomoeda e nenhuma trapa\xE7a \xE9 poss\xEDvel. Nenhum banco, ag\xEAncia governamental ou indiv\xEDduo poderia manipular criptomoedas. Em contraste com a moeda tradicional, as transa\xE7\xF5es de criptomoeda s\xE3o an\xF4nimas e n\xE3o h\xE1 amea\xE7a de confisco.</p>\r
  <h2>Como funciona a transa\xE7\xE3o de criptomoeda?</h2>\r
  <p>As transa\xE7\xF5es de criptomoeda s\xE3o realmente muito simples. Basicamente \xE9 enviar criptomoeda de uma carteira online para outra. O primeiro passo de todo o processo \xE9 que o pagador envia uma chave privada (uma sequ\xEAncia de n\xFAmeros gerada aleatoriamente) ao benefici\xE1rio, ap\xF3s o que uma transa\xE7\xE3o passar\xE1 por 0 a 5 valida\xE7\xF5es. Uma transa\xE7\xE3o comum passar\xE1 por 1 valida\xE7\xE3o, mas se o valor for muito grande, \xE9 melhor realizar v\xE1rias valida\xE7\xF5es. Demora cerca de 10 minutos para uma \xFAnica valida\xE7\xE3o na rede blockchain. Ap\xF3s a valida\xE7\xE3o, qualquer pessoa no blockchain pode verificar essa transa\xE7\xE3o, mas n\xE3o pode ver nenhuma informa\xE7\xE3o sens\xEDvel.</p>\r
  <h2>Como comprar criptomoeda?</h2>\r
  <p>A criptomoeda pode ser comprada nos seguintes locais:</p>\r
  <p>Troca de mercado: se o comprador n\xE3o se importa muito com privacidade, uma troca de mercado online \xE9 a melhor op\xE7\xE3o para comprar criptomoedas, porque as trocas de mercado geralmente exigem que os compradores forne\xE7am identifica\xE7\xE3o. Os compradores podem comprar criptomoeda de uma bolsa de mercado e armazen\xE1-la l\xE1.</p>\r
  <p>No balc\xE3o: Isso significa que duas pessoas realizam uma transa\xE7\xE3o de criptomoeda cara a cara. Normalmente, as transa\xE7\xF5es de criptomoeda s\xE3o realizadas anonimamente entre as duas partes. Embora a abordagem presencial n\xE3o tenha esse benef\xEDcio, ainda \xE9 muito popular. Vendedores e compradores podem entrar em contato uns com os outros atrav\xE9s de muitos sites.</p>\r
  <p>Caixa eletr\xF4nico de criptomoeda: esses caixas eletr\xF4nicos n\xE3o s\xE3o diferentes do caixa eletr\xF4nico normal, exceto que o comprador recebe um recibo com um determinado c\xF3digo em vez de dinheiro. Ao digitalizar o c\xF3digo, o bitcoin ser\xE1 transferido para a carteira do comprador.</p>\r
  <h2>A criptomoeda \xE9 legal?</h2>\r
  <p>Simplificando, o status legal da criptomoeda est\xE1 melhorando. Nos \xFAltimos meses, o Jap\xE3o anunciou o reconhecimento do bitcoin como moeda legal, e a R\xFAssia tamb\xE9m declarou seu plano de reconhecer o bitcoin como uma ferramenta financeira. Esta \xE9 uma grande mudan\xE7a de postura para a R\xFAssia, j\xE1 que o bitcoin foi originalmente banido na R\xFAssia.</p>\r
  <p>Enquanto a criptomoeda gradualmente se torna uma moeda global forte e importante, esse tipo de mudan\xE7a tamb\xE9m aumentar\xE1. A regulamenta\xE7\xE3o, uso e tributa\xE7\xE3o de criptomoedas ainda variam entre os pa\xEDses. Por outro lado, novas leis e regras s\xE3o publicadas o tempo todo. Se voc\xEA deseja saber em detalhes sobre a posi\xE7\xE3o do seu governo sobre criptomoedas e poss\xEDveis mudan\xE7as no futuro, entre em contato com um consultor jur\xEDdico.</p>\r
  <h2>Carteira Bitcoin</h2>\r
  <p>Existem muitas carteiras de bitcoin dispon\xEDveis. Existem carteiras baseadas em nuvem, bem como carteiras que podem ser baixadas para computadores pessoais, tablets ou telefones celulares. Voc\xEA tamb\xE9m pode obter uma carteira de hardware f\xEDsica que armazena criptomoedas. Existe uma fun\xE7\xE3o comum entre as v\xE1rias carteiras, que \xE9 transferir criptomoedas, mas cada carteira tem seu pr\xF3prio m\xE9rito.</p>\r
  <h2>Carteira baseada em nuvem</h2>\r
  <p>A carteira baseada em nuvem \xE9 a carteira mais f\xE1cil e conveniente de usar. No entanto, armazenar criptomoeda na nuvem significa entregar a responsabilidade de armazenar para a empresa que guarda sua criptomoeda. Portanto, a confian\xE7a m\xFAtua entre as duas partes \xE9 vital para armazenar criptomoedas em uma carteira baseada em nuvem.</p></section><section>\r
  <p><span lang="pt" jsaction="mouseup:BR6jm" jsname="jqKxS" xml:lang="pt"><span jsaction="agoMJf:PFBcW;usxOmf:aWLT7;jhKsnd:P7O7bd,F8DmGf;Q4AGo:Gm7gYd,qAKMYb;uFUCPb:pvnm0e,pfE8Hb,PFBcW;f56efd:dJXsye;EnoYf:KNzws,ZJsZZ,JgVSJc;zdMJQc:cCQNKb,ZJsZZ,zchEXc;Ytrrj:JJDvdc;tNR8yc:GeFvjb;oFN6Ye:hij5Wb;bmeZHc:iURhpf;Oxj3Xe:qAKMYb,yaf12d" jsname="txFAF" data-language-for-alternatives="pt" data-language-to-translate-into="it" data-phrase-index="0" data-number-of-phrases="1" jscontroller="Zl5N8" jsdata="uqLsIf;_;$6351" jsmodel="SsMkhd"><span jsaction="click:qtZ4nf,GFf3ac,tMZCfe; contextmenu:Nqw7Te,QP7LD; mouseout:Nqw7Te; mouseover:qtZ4nf,c2aHje" jsname="W297wb">Recomendamos a seguinte carteira baseada em cloud:</span></span></span></p>\r
  <ul>\r
    <li>\r
      <p>\r
        <a href="https://copay.io/" target="_blank" rel="noopener noreferrer"> copay.io </a>\r
      </p>\r
    </li>\r
    <li>\r
      <p>\r
        <a href="https://www.bitgo.com/" target="_blank" rel="noopener noreferrer"> bitgo.com </a>\r
      </p>\r
    </li>\r
  </ul>\r
</section>\r
\r
<section>\r
  <h2>Software wallet</h2>\r
  <p><span lang="pt" jsaction="mouseup:BR6jm" jsname="jqKxS" xml:lang="pt"><span jsaction="agoMJf:PFBcW;usxOmf:aWLT7;jhKsnd:P7O7bd,F8DmGf;Q4AGo:Gm7gYd,qAKMYb;uFUCPb:pvnm0e,pfE8Hb,PFBcW;f56efd:dJXsye;EnoYf:KNzws,ZJsZZ,JgVSJc;zdMJQc:cCQNKb,ZJsZZ,zchEXc;Ytrrj:JJDvdc;tNR8yc:GeFvjb;oFN6Ye:hij5Wb;bmeZHc:iURhpf;Oxj3Xe:qAKMYb,yaf12d" jsname="txFAF" data-language-for-alternatives="pt" data-language-to-translate-into="en" data-phrase-index="0" data-number-of-phrases="5" jscontroller="Zl5N8" jsdata="uqLsIf;_;$6397" jsmodel="SsMkhd"><span jsaction="click:qtZ4nf,GFf3ac,tMZCfe; contextmenu:Nqw7Te,QP7LD; mouseout:Nqw7Te; mouseover:qtZ4nf,c2aHje" jsname="W297wb">Uma carteira de software \xE9 um programa para download que pode ser executado em computadores, tablets ou telefones celulares.</span></span> <span jsaction="agoMJf:PFBcW;usxOmf:aWLT7;jhKsnd:P7O7bd,F8DmGf;Q4AGo:Gm7gYd,qAKMYb;uFUCPb:pvnm0e,pfE8Hb,PFBcW;f56efd:dJXsye;EnoYf:KNzws,ZJsZZ,JgVSJc;zdMJQc:cCQNKb,ZJsZZ,zchEXc;Ytrrj:JJDvdc;tNR8yc:GeFvjb;oFN6Ye:hij5Wb;bmeZHc:iURhpf;Oxj3Xe:qAKMYb,yaf12d" jsname="txFAF" data-language-for-alternatives="pt" data-language-to-translate-into="en" data-phrase-index="1" data-number-of-phrases="5" jscontroller="Zl5N8" jsdata="uqLsIf;_;$6398" jsmodel="SsMkhd"><span jsaction="click:qtZ4nf,GFf3ac,tMZCfe; contextmenu:Nqw7Te,QP7LD; mouseout:Nqw7Te; mouseover:qtZ4nf,c2aHje" jsname="W297wb">Uma carteira de software \xE9 mais segura do que uma baseada em nuvem porque voc\xEA pode assumir o controle total dela.</span></span> <span jsaction="agoMJf:PFBcW;usxOmf:aWLT7;jhKsnd:P7O7bd,F8DmGf;Q4AGo:Gm7gYd,qAKMYb;uFUCPb:pvnm0e,pfE8Hb,PFBcW;f56efd:dJXsye;EnoYf:KNzws,ZJsZZ,JgVSJc;zdMJQc:cCQNKb,ZJsZZ,zchEXc;Ytrrj:JJDvdc;tNR8yc:GeFvjb;oFN6Ye:hij5Wb;bmeZHc:iURhpf;Oxj3Xe:qAKMYb,yaf12d" jsname="txFAF" data-language-for-alternatives="pt" data-language-to-translate-into="en" data-phrase-index="2" data-number-of-phrases="5" jscontroller="Zl5N8" jsdata="uqLsIf;_;$6399" jsmodel="SsMkhd"><span jsaction="click:qtZ4nf,GFf3ac,tMZCfe; contextmenu:Nqw7Te,QP7LD; mouseout:Nqw7Te; mouseover:qtZ4nf,c2aHje" jsname="W297wb">No entanto, uma carteira de software ainda tem seus riscos.</span></span><span jsaction="agoMJf:PFBcW;usxOmf:aWLT7;jhKsnd:P7O7bd,F8DmGf;Q4AGo:Gm7gYd,qAKMYb;uFUCPb:pvnm0e,pfE8Hb,PFBcW;f56efd:dJXsye;EnoYf:KNzws,ZJsZZ,JgVSJc;zdMJQc:cCQNKb,ZJsZZ,zchEXc;Ytrrj:JJDvdc;tNR8yc:GeFvjb;oFN6Ye:hij5Wb;bmeZHc:iURhpf;Oxj3Xe:qAKMYb,yaf12d" jsname="txFAF" data-language-for-alternatives="pt" data-language-to-translate-into="en" data-phrase-index="3" data-number-of-phrases="5" jscontroller="Zl5N8" jsdata="uqLsIf;_;$6400" jsmodel="SsMkhd"><span jsaction="click:qtZ4nf,GFf3ac,tMZCfe; contextmenu:Nqw7Te,QP7LD; mouseout:Nqw7Te; mouseover:qtZ4nf,c2aHje" jsname="W297wb"> </span></span><span jsaction="agoMJf:PFBcW;usxOmf:aWLT7;jhKsnd:P7O7bd,F8DmGf;Q4AGo:Gm7gYd,qAKMYb;uFUCPb:pvnm0e,pfE8Hb,PFBcW;f56efd:dJXsye;EnoYf:KNzws,ZJsZZ,JgVSJc;zdMJQc:cCQNKb,ZJsZZ,zchEXc;Ytrrj:JJDvdc;tNR8yc:GeFvjb;oFN6Ye:hij5Wb;bmeZHc:iURhpf;Oxj3Xe:qAKMYb,yaf12d" jsname="txFAF" data-language-for-alternatives="pt" data-language-to-translate-into="en" data-phrase-index="4" data-number-of-phrases="5" jscontroller="Zl5N8" jsdata="uqLsIf;_;$6401" jsmodel="SsMkhd"><span jsaction="click:qtZ4nf,GFf3ac,tMZCfe; contextmenu:Nqw7Te,QP7LD; mouseout:Nqw7Te; mouseover:qtZ4nf,c2aHje" jsname="W297wb">Recomendamos as seguintes carteiras de software:</span></span></span></p>\r
  <ul>\r
    <li>\r
      <p>\r
        <a href="https://copay.io/" target="_blank" rel="noopener noreferrer"> copay.io </a>\r
      </p>\r
    </li>\r
    <li>\r
      <p>\r
        <a href="https://breadapp.com/" target="_blank" rel="noopener noreferrer"> Breadwallet </a>\r
      </p>\r
    </li>\r
    <li>\r
      <p>\r
        <a href="https://www.mycelium.com/" target="_blank" rel="noopener noreferrer"> Mycelium </a>\r
      </p>\r
    </li>\r
  </ul>\r
</section>\r
\r
<section>\r
  <h2>Hardware Wallet</h2>\r
  <p><span lang="pt" jsaction="mouseup:BR6jm" jsname="jqKxS" xml:lang="pt"><span jsaction="agoMJf:PFBcW;usxOmf:aWLT7;jhKsnd:P7O7bd,F8DmGf;Q4AGo:Gm7gYd,qAKMYb;uFUCPb:pvnm0e,pfE8Hb,PFBcW;f56efd:dJXsye;EnoYf:KNzws,ZJsZZ,JgVSJc;zdMJQc:cCQNKb,ZJsZZ,zchEXc;Ytrrj:JJDvdc;tNR8yc:GeFvjb;oFN6Ye:hij5Wb;bmeZHc:iURhpf;Oxj3Xe:qAKMYb,yaf12d" jsname="txFAF" data-language-for-alternatives="pt" data-language-to-translate-into="en" data-phrase-index="0" data-number-of-phrases="5" jscontroller="Zl5N8" jsdata="uqLsIf;_;$6431" jsmodel="SsMkhd"><span jsaction="click:qtZ4nf,GFf3ac,tMZCfe; contextmenu:Nqw7Te,QP7LD; mouseout:Nqw7Te; mouseover:qtZ4nf,c2aHje" jsname="W297wb">Uma carteira de hardware armazena a chave privada do usu\xE1rio em um dispositivo de hardware seguro.</span></span> <span jsaction="agoMJf:PFBcW;usxOmf:aWLT7;jhKsnd:P7O7bd,F8DmGf;Q4AGo:Gm7gYd,qAKMYb;uFUCPb:pvnm0e,pfE8Hb,PFBcW;f56efd:dJXsye;EnoYf:KNzws,ZJsZZ,JgVSJc;zdMJQc:cCQNKb,ZJsZZ,zchEXc;Ytrrj:JJDvdc;tNR8yc:GeFvjb;oFN6Ye:hij5Wb;bmeZHc:iURhpf;Oxj3Xe:qAKMYb,yaf12d" jsname="txFAF" data-language-for-alternatives="pt" data-language-to-translate-into="en" data-phrase-index="1" data-number-of-phrases="5" jscontroller="Zl5N8" jsdata="uqLsIf;_;$6432" jsmodel="SsMkhd"><span jsaction="click:qtZ4nf,GFf3ac,tMZCfe; contextmenu:Nqw7Te,QP7LD; mouseout:Nqw7Te; mouseover:qtZ4nf,c2aHje" jsname="W297wb">Em compara\xE7\xE3o com as carteiras de software, uma das principais vantagens das carteiras de hardware \xE9 a imunidade contra v\xEDrus de computador.</span></span> <span jsaction="agoMJf:PFBcW;usxOmf:aWLT7;jhKsnd:P7O7bd,F8DmGf;Q4AGo:Gm7gYd,qAKMYb;uFUCPb:pvnm0e,pfE8Hb,PFBcW;f56efd:dJXsye;EnoYf:KNzws,ZJsZZ,JgVSJc;zdMJQc:cCQNKb,ZJsZZ,zchEXc;Ytrrj:JJDvdc;tNR8yc:GeFvjb;oFN6Ye:hij5Wb;bmeZHc:iURhpf;Oxj3Xe:qAKMYb,yaf12d" jsname="txFAF" data-language-for-alternatives="pt" data-language-to-translate-into="en" data-phrase-index="2" data-number-of-phrases="5" jscontroller="Zl5N8" jsdata="uqLsIf;_;$6433" jsmodel="SsMkhd"><span jsaction="click:qtZ4nf,GFf3ac,tMZCfe; contextmenu:Nqw7Te,QP7LD; mouseout:Nqw7Te; mouseover:qtZ4nf,c2aHje" jsname="W297wb">Al\xE9m disso, como a chave privada \xE9 armazenada na zona protegida de um microcontrolador, ela n\xE3o pode ser transferida para fora do dispositivo em texto n\xE3o criptografado.</span></span><span jsaction="agoMJf:PFBcW;usxOmf:aWLT7;jhKsnd:P7O7bd,F8DmGf;Q4AGo:Gm7gYd,qAKMYb;uFUCPb:pvnm0e,pfE8Hb,PFBcW;f56efd:dJXsye;EnoYf:KNzws,ZJsZZ,JgVSJc;zdMJQc:cCQNKb,ZJsZZ,zchEXc;Ytrrj:JJDvdc;tNR8yc:GeFvjb;oFN6Ye:hij5Wb;bmeZHc:iURhpf;Oxj3Xe:qAKMYb,yaf12d" jsname="txFAF" data-language-for-alternatives="pt" data-language-to-translate-into="en" data-phrase-index="3" data-number-of-phrases="5" jscontroller="Zl5N8" jsdata="uqLsIf;_;$6434" jsmodel="SsMkhd"><span jsaction="click:qtZ4nf,GFf3ac,tMZCfe; contextmenu:Nqw7Te,QP7LD; mouseout:Nqw7Te; mouseover:qtZ4nf,c2aHje" jsname="W297wb"> </span></span><span jsaction="agoMJf:PFBcW;usxOmf:aWLT7;jhKsnd:P7O7bd,F8DmGf;Q4AGo:Gm7gYd,qAKMYb;uFUCPb:pvnm0e,pfE8Hb,PFBcW;f56efd:dJXsye;EnoYf:KNzws,ZJsZZ,JgVSJc;zdMJQc:cCQNKb,ZJsZZ,zchEXc;Ytrrj:JJDvdc;tNR8yc:GeFvjb;oFN6Ye:hij5Wb;bmeZHc:iURhpf;Oxj3Xe:qAKMYb,yaf12d" jsname="txFAF" data-language-for-alternatives="pt" data-language-to-translate-into="en" data-phrase-index="4" data-number-of-phrases="5" jscontroller="Zl5N8" jsdata="uqLsIf;_;$6435" jsmodel="SsMkhd"><span jsaction="click:qtZ4nf,GFf3ac,tMZCfe; contextmenu:Nqw7Te,QP7LD; mouseout:Nqw7Te; mouseover:qtZ4nf,c2aHje" jsname="W297wb">Recomendamos as seguintes carteiras de hardware:</span></span></span></p>\r
  <ul>\r
    <li>\r
      <p>\r
        <a href="https://trezor.io/" target="_blank" rel="noopener noreferrer"> Trezor </a>\r
      </p>\r
    </li>\r
    <li>\r
      <p>\r
        <a href="https://www.ledgerwallet.com/" target="_blank" rel="noopener noreferrer"> Ledger </a>\r
      </p>\r
    </li>\r
  </ul>\r
  <p>Para saber mais sobre v\xE1rias carteiras de bitcoin, visite Bitcoin.org.</p>\r
  <h2>Proteja sua carteira</h2>\r
  <p>Quando usado corretamente, o bitcoin \xE9 altamente seguro. Lembre-se sempre de que \xE9 sua responsabilidade tomar medidas para proteger seu dinheiro.</p>\r
  <p>Voc\xEA deve considerar os seguintes pontos:</p>\r
  <p>Como moeda legal, n\xE3o coloque todo o seu dinheiro em uma carteira.</p>\r
  <p>Escolha sua carteira online com cuidado. 2FA \xE9 uma boa garantia extra.</p>\r
  <p>Fa\xE7a backup de sua carteira regularmente. Tamb\xE9m \xE9 uma boa pr\xE1tica criptografar backups expostos \xE0 Internet.</p>\r
  <p>Armazene a senha em um local seguro. Voc\xEA pode memorizar sua senha ou armazen\xE1-la em um local f\xEDsico seguro.</p>\r
  <p>Escolha uma senha forte que contenha letras, n\xFAmeros e s\xEDmbolos e tenha pelo menos 16 caracteres.</p>\r
  <p>A carteira offline, tamb\xE9m conhecida como armazenamento a frio, oferece a mais alta seguran\xE7a para o seu dep\xF3sito. \xC9 para esconder a carteira em um local seguro que n\xE3o esteja conectado \xE0 Internet. Se bem implementada, esta op\xE7\xE3o pode fornecer excelente prote\xE7\xE3o contra vulnerabilidades do computador.</p>\r
</section>\r
<section>\r
</section>`,r=`<section>
  <h2>Apa itu mata uang kripto?</h2>
  <p>
    
Cryptocurrency adalah mata uang digital yang tidak bergantung pada substansi nyata apa pun dan menggunakan kriptografi, mis. Bitcoin, litcoin, BitShares, dll. Ini adalah mata uang digital yang dibuat, didistribusikan, dan dikelola berdasarkan kriptografi dan teknologi validasi. Karakteristik cryptocurrency adalah penerapan teknologi P2P dan fakta bahwa semua orang mengeluarkannya.


  </p>
  <p>
    Cryptocurrency juga merupakan sistem pembayaran online yang mendukung transaksi anonim. Bitcoin adalah cryptocurrency teratas, dan diakui oleh undang-undang di banyak negara.
  </p>
</section>

<section>
  <h2>Mengapa menggunakan mata uang digital?</h2>
  <p>
    Karena beberapa alasan, crytocurrency adalah mata uang digital yang paling populer dan paling banyak digunakan. Berbeda dengan transfer tradisional, transfer Kami tidak memerlukan beberapa jam menunggu, dan tidak terpengaruh oleh jumlah transfer atau wilayah pengguna. Biayanya juga jauh lebih rendah, dan biasanya hanya beberapa sen. Pengembalian dana tidak akan terjadi pada mata uang kripto, dan tidak ada kecurangan yang dimungkinkan. Tidak ada bank, lembaga pemerintah, atau individu yang dapat memanipulasi mata uang kripto. Berbeda dengan mata uang tradisional, transaksi mata uang kripto bersifat anonim, dan tidak ada ancaman penyitaan.
  </p>
</section>

<section>
  <h2>Bagaimana cara kerja transaksi mata uang kripto?</h2>
  <p>
    Transaksi mata uang kripto sebenarnya sangat sederhana. Pada dasarnya ini adalah untuk mengirim mata uang kripto dari dompet online ke dompet lain. Langkah pertama dalam keseluruhan proses adalah bahwa pembayar mengirimkan kunci pribadi (urutan angka yang dibuat secara acak) ke penerima pembayaran, setelah itu sebuah transaksi akan melalui 0 hingga 5 validasi. Transaksi biasa akan melalui 1 validasi, tetapi jika jumlahnya sangat besar, lebih baik melakukan validasi berulang kali. Dibutuhkan sekitar 10 menit untuk satu validasi pada jaringan blockchain. Setelah validasi, siapa pun di blockchain dapat memeriksa transaksi ini tetapi tidak dapat melihat informasi sensitif apa pun.
  </p>
</section>

<section>
  <h2>Bagaimana cara membeli mata uang kripto?</h2>
  <p>Mata uang kripto dapat dibeli di tempat-tempat berikut:</p>
  <p>
    Pertukaran pasar: Jika pembeli tidak terlalu peduli dengan privasi, maka pertukaran pasar online adalah pilihan terbaik untuk membeli cryptocurrency karena pertukaran pasar biasanya mengharuskan pembeli untuk memberikan identifikasi. Pembeli dapat membeli cryptocurrency dari bursa pasar dan menyimpannya di sana.
  </p>
  <p>
    Over the counter: Ini berarti dua orang melakukan transaksi cryptocurrency secara tatap muka. Biasanya transaksi ryptocurrency dilakukan secara anonim antara kedua belah pihak. Meskipun pendekatan tatap muka tidak menikmati manfaat ini, hal ini masih sangat populer. Penjual dan pembeli dapat menghubungi satu sama lain melalui banyak situs web.
  </p>
  <p>
    ATM mata uang kripto: ATM ini tidak berbeda dengan ATM biasa selain dari itu pembeli mendapat struk dengan kode tertentu sebagai ganti uang tunai. Dengan memindai kode tersebut, bitcoin akan ditransfer ke dompet pembeli.
  </p>
</section>

<section>
  <h2>Apakah mata uang kripto itu legal?</h2>
  <p>
    Sederhananya, status hukum cryptocurrency menjadi lebih baik. Dalam beberapa bulan terakhir, Jepang mengumumkan untuk mengakui bitcoin sebagai mata uang yang sah, dan Rusia juga menyatakan rencananya untuk mengakui bitcoin sebagai alat keuangan. Ini adalah perubahan sikap yang besar bagi Rusia, karena bitcoin pada awalnya dilarang di Rusia.
  </p>
  <p>
    Sementara mata uang kripto secara bertahap menjadi mata uang global yang kuat dan penting, perubahan semacam ini juga akan meningkat. Regulasi, penggunaan, dan perpajakan mata uang kripto masih bervariasi di berbagai negara. Di sisi lain, undang-undang dan aturan baru diterbitkan setiap saat. Jika Anda ingin mengetahui secara detail tentang sikap pemerintah Anda terhadap mata uang kripto dan potensi perubahan di masa mendatang, silakan hubungi konsultan hukum.
  </p>
</section>

<section>
  <h2>Dompet bitcoin</h2>
  <p>
   Ada banyak dompet bitcoin yang tersedia. Ada dompet berbasis cloud serta dompet yang dapat diunduh ke komputer pribadi, komputer tablet, atau ponsel. Anda juga bisa mendapatkan dompet perangkat keras fisik yang menyimpan mata uang digital. Ada fungsi umum di antara berbagai dompet, yaitu untuk mentransfer mata uang kripto, tetapi setiap dompet memiliki kelebihannya sendiri.
  </p>
</section>

<section>
  <h2>Dompet berbasis cloud (maya)</h2>
  <p>
    Dompet berbasis cloud atau maya adalah dompet yang paling mudah dan nyaman digunakan. Namun, menyimpan mata uang kripto di cloud berarti menyerahkan tanggung jawab penyimpanan kepada perusahaan yang menyimpan mata uang kripto Anda. Oleh karena itu, saling percaya antara kedua belah pihak sangat penting dalam menyimpan mata uang kripto di dompet berbasis cloud atau maya.
  </p>
  <p>Kami menyarankan dompet berbasis cloud berikut:</p>
  <ul>
    <li>
      <p>
        <a href="https://copay.io/" target="_blank" rel="noopener noreferrer"> copay.io </a>
      </p>
    </li>
    <li>
      <p>
        <a href="https://www.bitgo.com/" target="_blank" rel="noopener noreferrer"> bitgo.com </a>
      </p>
    </li>
  </ul>
</section>

<section>
  <h2>Dompet perangkat lunak (Software)</h2>
  <p>
    Dompet perangkat lunak adalah program yang dapat diunduh yang dapat dijalankan di komputer, komputer tablet, atau ponsel. Dompet perangkat lunak lebih aman daripada dompet berbasis cloud karena Anda dapat mengendalikannya sepenuhnya. Namun, dompet perangkat lunak masih memiliki risikonya sendiri.
  </p>
  <p>Kami merekomendasikan dompet perangkat lunak berikut:</p>
  <ul>
    <li>
      <p>
        <a href="https://copay.io/" target="_blank" rel="noopener noreferrer"> copay.io </a>
      </p>
    </li>
    <li>
      <p>
        <a href="https://breadapp.com/" target="_blank" rel="noopener noreferrer"> Breadwallet </a>
      </p>
    </li>
    <li>
      <p>
        <a href="https://www.mycelium.com/" target="_blank" rel="noopener noreferrer"> Mycelium </a>
      </p>
    </li>
  </ul>
</section>

<section>
  <h2>Dompet Perangkat Keras (hardware)</h2>
  <p>
    Dompet perangkat keras menyimpan kunci pribadi pengguna di perangkat keras yang aman. Dibandingkan dengan dompet perangkat lunak, salah satu keunggulan utama dompet perangkat keras adalah kekebalan terhadap virus komputer. Selain itu, karena kunci pribadi disimpan di zona terlindung dari mikrokontroler, kunci tersebut tidak dapat ditransfer keluar dari perangkat dalam bentuk teks yang jelas.
  </p>
  <p>Kami merekomendasikan dompet perangkat keras (hardware) berikut:</p>
  <ul>
    <li>
      <p>
        <a href="https://trezor.io/" target="_blank" rel="noopener noreferrer"> Trezor </a>
      </p>
    </li>
    <li>
      <p>
        <a href="https://www.ledgerwallet.com/" target="_blank" rel="noopener noreferrer"> Ledger </a>
      </p>
    </li>
  </ul>
  <p>Untuk mengetahui lebih banyak tentang berbagai dompet bitcoin, silakan kunjungi Bitcoin.org.</p>
</section>

<section>
  <h2>Lindungi dompet Anda</h2>
  <p>
    Ketika digunakan dengan benar, bitcoin sangat aman. Harap selalu diingat bahwa adalah tanggung jawab Anda untuk mengambil tindakan untuk melindungi uang Anda.
  </p>
  <p>Anda harus mempertimbangkan hal-hal berikut:</p>
  <p>Seperti alat pembayaran yang sah, jangan taruh semua uang Anda dalam satu dompet.</p>
  <p>Pilih dompet online Anda dengan cermat. 2FA adalah jaminan ekstra yang bagus.</p>
  <p>
    Cadangkan dompet Anda secara teratur. Ini juga merupakan praktik yang baik untuk mengenkripsi cadangan yang terpapar ke Internet.
  </p>
  <p>
    Simpan kata sandi di lokasi yang aman. Anda dapat mengingat kata sandi Anda, atau menyimpannya di lokasi fisik yang aman.
  </p>
  <p>
    Pilih kata sandi yang kuat yang berisi huruf, angka, dan simbol, dan panjangnya minimal 16 karakter.
  </p>
  <p>
    Dompet offline, juga dikenal sebagai penyimpanan dingin, memberikan keamanan tertinggi untuk deposit Anda. Hal ini untuk menyembunyikan dompet di tempat yang aman yang tidak terhubung ke Internet. Jika diterapkan dengan baik, opsi ini dapat memberikan perlindungan yang sangat baik terhadap kerentanan komputer.
  </p>
</section>
`;function s(){return e(a,{br:t,en:n,id:r})}export{s as default};
