import{H as a}from"./HelpPage.5a10ddbc.js";import{a as e}from"./index.28e31dff.js";var n=`<section>
  <h2>Google Authenticator</h2>
  <p>
    Google authenticator could provide an additional layer of security
    protection for your account. It is a software token that implements a 2-step
    verification program. In order to use Google authenticator, you must have a
    mobile phone because it will be installed as a mobile application. You can
    also use Google authenticator when offline.
  </p>
  <p>
    Google authenticator uses an algorithm to calculate one-time passwords based
    on time. Simply put, once the application is started, Google authenticator
    will display a randomly generated 6-digit sequence of numbers, ie, a
    one-time password. If you have enabled 2FA in your account, then in addition
    to entering your usual password, you also need to enter the randomly
    generated one-time password. 2FA provides additional security protection
    because it makes sure that others cannot login to your account with your
    username and password alone.
  </p>
  <p>
    We highly values the security of the players, so we strongly recommend you
    to use Google authenticator. This small extra step could protect you against
    necessary headache and anxiety.
  </p>
  <p>
    If you have enabled Google authenticator, you will be prompted to complete
    2FA every time you login or withdraw. Furthermore, please print out the QR
    code or write down the manual code that could recover your account. In case
    of mobile phone breakdown or loss, this will help you to a great extent.
  </p>
  <p>
    To know more about Google authenticator.
    <a
      href="https://support.google.com/accounts/answer/1066447?hl=zh-Hans"
      target="_blank"
      rel="noopener noreferrer"
    >
      Google authenticator
    </a>
  </p>
</section>
`,o=`<section>\r
  <h2>Google Authenticator</h2>\r
  <p><br>\r
  O autenticador do Google pode fornecer uma camada adicional de prote\xE7\xE3o de seguran\xE7a para sua conta. \xC9 um token de software que implementa um programa de verifica\xE7\xE3o em duas etapas. Para usar o autenticador do Google, voc\xEA deve ter um celular, pois ele ser\xE1 instalado como um aplicativo m\xF3vel. Voc\xEA tamb\xE9m pode usar o autenticador do Google quando estiver offline.</p>\r
  <p>O autenticador do Google usa um algoritmo para calcular senhas de uso \xFAnico com base no tempo. Simplificando, assim que o aplicativo for iniciado, o autenticador do Google exibir\xE1 uma sequ\xEAncia de n\xFAmeros de 6 d\xEDgitos gerada aleatoriamente, ou seja, uma senha de uso \xFAnico. Se voc\xEA ativou o 2FA em sua conta, al\xE9m de inserir sua senha usual, tamb\xE9m precisar\xE1 inserir a senha de uso \xFAnico gerada aleatoriamente. A 2FA fornece prote\xE7\xE3o de seguran\xE7a adicional porque garante que outras pessoas n\xE3o possam acessar sua conta apenas com seu nome de usu\xE1rio e senha.</p>\r
  <p>Valorizamos muito a seguran\xE7a dos jogadores, por isso recomendamos que voc\xEA use o autenticador do Google. Este pequeno passo extra pode proteg\xEA-lo contra a dor de cabe\xE7a e a ansiedade necess\xE1rias.</p>\r
  <p>Se voc\xEA ativou o autenticador do Google, ser\xE1 solicitado que voc\xEA complete o 2FA toda vez que fizer login ou sair. Al\xE9m disso, imprima o c\xF3digo QR ou anote o c\xF3digo manual que pode recuperar sua conta. Em caso de avaria ou perda do telem\xF3vel, isso ir\xE1 ajud\xE1-lo em grande medida. <a href="https://support.google.com/accounts/answer/1066447?hl=pt-BR" target="_blank" rel="noopener noreferrer">Google authenticator\r
    </a>\r
  </p>\r
</section>`,t=`<section>
  <h2>Google Authenticator</h2>
  <p>
    Authenticator Google bisa memberikan lapisan keamanan tambahan
     perlindungan untuk akun Anda. Ini adalah token perangkat lunak yang menerapkan 2-langkah
     program verifikasi. Untuk menggunakan Google authenticator, Anda harus memiliki
     ponsel karena akan dipasang sebagai aplikasi mobile. Anda bisa
     juga menggunakan Google authenticator saat offline.
  </p>
  <p>
    Autentikator Google menggunakan algoritme untuk menghitung kata sandi satu kali berdasarkan
     pada waktunya. Sederhananya, setelah aplikasi dimulai, Google authenticator
     akan menampilkan urutan angka 6 digit yang dihasilkan secara acak, yaitu, a
     kata sandi sekali pakai. Jika Anda telah mengaktifkan 2FA di akun Anda, maka sebagai tambahan
     untuk memasukkan kata sandi Anda yang biasa, Anda juga harus memasukkan kata sandi secara acak
     kata sandi satu kali yang dihasilkan. 2FA memberikan perlindungan keamanan tambahan
     karena memastikan bahwa orang lain tidak dapat masuk ke akun Anda dengan
     nama pengguna dan kata sandi saja.
  </p>
  <p>
    Kami sangat menghargai keamanan para pemain, jadi kami sangat menyarankan Anda
     untuk menggunakan Google authenticator. Langkah ekstra kecil ini dapat melindungi Anda dari serangan
     sakit kepala dan kecemasan yang tidak diperlukan.
  </p>
  <p>
    Jika Anda telah mengaktifkan Google authenticator, Anda akan diminta untuk menyelesaikan
     2FA setiap kali Anda login atau withdraw. Selanjutnya, silakan cetak QR
     kode atau tuliskan kode manual yang dapat memulihkan akun Anda. Dalam hal
     kerusakan atau kehilangan ponsel, ini akan sangat membantu Anda.
  </p>
  <p>
    Untuk mengetahui lebih lanjut tentang Google authenticator.
    <a
      href="https://support.google.com/accounts/answer/1066447?hl=zh-Hans"
      target="_blank"
      rel="noopener noreferrer"
    >
      Google authenticator
    </a>
  </p>
</section>
`;function s(){return e(a,{br:o,en:n,id:t})}export{s as default};
