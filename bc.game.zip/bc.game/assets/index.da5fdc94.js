import{H as e}from"./HelpPage.5a10ddbc.js";import{fo as o,j as n,F as t,fp as r,a}from"./index.28e31dff.js";var i=`<section>
  <h2>Start your game journey</h2>
  <p>Can I register on your website?</p>
  <p>
    You must be at least 18 years old or reach the age of majority under your
    jurisdiction. You must be permitted to play online games by the laws
    applicable to you. For more information, please read our terms and
    conditions.
  </p>
  <p>Games might be addictive, and players are advised to be self-control.</p>
</section>

<section>
  <h2>Account Information</h2>
  <p class="em">1. What if I forget my password?</p>
  <p>
    If you forget your password, you could reset it within 15 seconds through
    our \u201CForget password\u201D link. After applying for password reset, please follow
    the instructions in the email we send to you to reset your password.
  </p>
  <p class="em">
    2. I have lost my mobile phone. How do I reset my Google authenticator?
  </p>
  <p>
    If you want to remove your Google authenticator 2FA, please contact us.
    After we receive your application, for the safety of your account, you are
    required to answer several security questions correctly in order to remove
    the 2FA.
  </p>
  <p class="em">3. Can I change my username or registered email address?</p>
  <p>
    Sorry, but we are not able to update this information. If you insist on
    changing your username and/or registered email, we suggest you close the
    current account and register a new one.
  </p>
  <p class="em">4. How do I become a VIP?</p>
  <p>
    The exclusive VIP club is by invitation only. After you embark on your
    journey of the game, you will be notified of your VIP status by email soon.
  </p>
</section>

<section>
  <h2>My wallet</h2>
  <p>
    \u300EMy wallet\u300F is part of the player account. You can view the balance of all
    cooperative cryptocurrencies, deposit and withdraw and query transaction
    records. Furthermore, you can also get access to BC Swap without review and
    Vault Pro with an annual percentage rate (APR) of 5%.
  </p>
</section>

<section>
  <h2>How to deposit</h2>
  <p>
    1. Find the\u300EMy wallet\u300F page, click the deposit page, copy the wallet
    address, or scan QR code for payment.
  </p>
  <p>
    2. Use From Alcoin to deposit the 150 cryptocurrencies provided by
    Changelly.
  </p>
  <p>3. Quickly deposit and withdrawal directly from the cooperative wallet.</p>
  <p>
    <a class="cl-primary" href="/wallet/deposit">Deposit</a>
  </p>
</section>

<section>
  <h2>What is BC Swap</h2>
  <p>
    You can use BC Swap to exchange cryptocurrencies without waiting for review.
  </p>
</section>

<section>
  <h2>What is Vault Pro</h2>
  <p>
    This is the BC exclusive bank that you can get annual percentage rate (APR)
    of 5% from your deposit in the Vault Pro.
  </p>
</section>

<section>
  <h2>How to withdraw</h2>
  <p>
    find the\u300EMy wallet\u300Fpage, open the withdraw page, enter the address of the
    wallet you need to withdraw and the amount of cryptocurrency (pay attention
    to the fee). After clicking the confirm button, the cryptocurrency will be
    transferred to your wallet (pay attention to the corresponding
    cryptocurrency).
  </p>
  <p>
    <a class="cl-primary" href="/wallet/withdraw">Withdraw</a>
  </p>
</section>

<section>
  <h2>Minimum Withdraw amount</h2>
  <p>
    Because the value of each cryptocurrency is different, the minimum Withdraw
    amount is also different
  </p>
</section>

<section>
  <h2>How long does it take to deposit and withdraw?</h2>
  <p>
    Each transaction on the blockchain requires several cycles to confirm the
    transfer has been recorded successfully.
  </p>
  <p>
    Generally speaking, each transaction requires 5-10 minutes before it can be
    confirmed by the blockchain network.
  </p>
  <p>
    If you encounter any problem during deposit or Withdraw, you can visit
    <a href="https://blockchain.info/">www.blockchain.info</a> to check your
    transaction, or contact technical support.
  </p>
</section>

<section>
  <h2>Before Withdraw, how many confirmations is required on my deposit?</h2>
  <p>
    To withdraw, your total deposit requires at least 3 verifications. You may
    check the current verification progress information by clicking on the
    deposit link in the cashier page.
  </p>
</section>

<section>
  <h2>Where do transaction confirmations come from?</h2>
  <p>
    All confirmation information comes from the wallet supplier, the blockchain
    and miners.
  </p>
</section>

<section>
  <h2>How long does it take to confirm a transaction?</h2>
  <p>
    It depends on the blockchain and your transfer fee. It might take 10 minutes
    or several hours.
  </p>
</section>

<section>
  <h2>Is your game fair and just?</h2>
  <p>
    We are based on the Ethereum smart contract. All data and core logic on the
    blockchain are transparent, and manipulation is not possible. Every single
    transaction on the blockchain can be tracked on etherscan. The fairness,
    openness, and justness of us gaming platform are guaranteed.
  </p>
</section>

<section>
  <h2>What should I do if my game hangs or there is a problem?</h2>
  <p>
    If you encounter any technical problem while playing our games, please try
    to refresh the game. Normally it will work after refresh. Should the problem
    persist, please contact us.
  </p>
</section>
`,s=`<section>\r
  <p>Autenticador do Google<br>\r
    Comece sua jornada de jogo</p>\r
  <p>Posso me cadastrar no seu site?</p>\r
  <p>Voc\xEA deve ter pelo menos 18 anos ou atingir a maioridade sob sua jurisdi\xE7\xE3o. Voc\xEA deve ter permiss\xE3o para jogar jogos online de acordo com as leis aplic\xE1veis \u200B\u200Ba voc\xEA. Para mais informa\xE7\xF5es, por favor leia nossos termos e condi\xE7\xF5es.</p>\r
  <p>Os jogos podem ser viciantes e os jogadores s\xE3o aconselhados a ter autocontrole.</p>\r
  <p>Informa\xE7\xE3o da conta</p>\r
  <p>1. E se eu esquecer minha senha?</p>\r
  <p>Se voc\xEA esquecer sua senha, poder\xE1 redefini-la em 15 segundos atrav\xE9s do nosso link \u201CEsqueci minha senha\u201D. Ap\xF3s solicitar a redefini\xE7\xE3o de senha, siga as instru\xE7\xF5es no e-mail que lhe enviamos para redefinir sua senha.</p>\r
  <p>2. Perdi meu celular. Como fa\xE7o para redefinir meu autenticador do Google?</p>\r
  <p>Se voc\xEA deseja remover o 2FA do autenticador do Google, entre em contato conosco. Ap\xF3s recebermos sua inscri\xE7\xE3o, para a seguran\xE7a de sua conta, voc\xEA dever\xE1 responder a v\xE1rias perguntas de seguran\xE7a corretamente para remover o 2FA.</p>\r
  <p>3. Posso alterar meu nome de usu\xE1rio ou endere\xE7o de e-mail registrado?</p>\r
  <p>Desculpe, mas n\xE3o podemos atualizar esta informa\xE7\xE3o. Caso insista em alterar seu nome de usu\xE1rio e/ou e-mail cadastrado, sugerimos que encerre a conta atual e registre uma nova.</p>\r
  <p>4. Como me torno um VIP?</p>\r
  <p>O clube VIP exclusivo \xE9 apenas para convidados. Depois de embarcar em sua jornada no jogo, voc\xEA ser\xE1 notificado de seu status VIP por e-mail em breve.</p>\r
</section>\r
\r
<section>\r
  <p>Minha carteira</p>\r
  <p>\u300EMinha carteira\u300F faz parte da conta do jogador. Voc\xEA pode visualizar o saldo de todas as criptomoedas cooperativas, depositar e sacar e consultar registros de transa\xE7\xF5es. Al\xE9m disso, voc\xEA tamb\xE9m pode acessar o BC Swap sem revis\xE3o e o Vault Pro com uma taxa percentual anual (APR) de 5%.</p>\r
  <p>Como depositar</p>\r
  <p>1. Encontre a p\xE1gina \u300EMinha carteira\u300F, clique na p\xE1gina de dep\xF3sito, copie o endere\xE7o da carteira ou escaneie o c\xF3digo QR para pagamento.</p>\r
  <p>2. Use From Alcoin para depositar as 150 criptomoedas fornecidas pela Changelly.</p>\r
  <p>3. Deposite e saque rapidamente diretamente da carteira cooperativa.</p>\r
  <p>Dep\xF3sito</p>\r
  <p>O que \xE9 BC Swap</p>\r
  <p>Voc\xEA pode usar BC Swap para trocar criptomoedas sem esperar pela revis\xE3o.</p>\r
  <p>O que \xE9 o Vault Pro</p>\r
  <p>Este \xE9 o banco exclusivo do BC que voc\xEA pode obter a taxa percentual anual (APR) de 5% do seu dep\xF3sito no Vault Pro.</p>\r
  <p>Como retirar</p>\r
  <p>encontre a p\xE1gina \u300EMinha carteira\u300F, abra a p\xE1gina de retirada, digite o endere\xE7o da carteira que voc\xEA precisa retirar e a quantidade de criptomoeda (preste aten\xE7\xE3o \xE0 taxa). Ap\xF3s clicar no bot\xE3o confirmar, a criptomoeda ser\xE1 transferida para sua carteira (preste aten\xE7\xE3o \xE0 criptomoeda correspondente).</p>\r
  <p>Retirar</p>\r
  <p>Valor m\xEDnimo de saque</p>\r
  <p>Como o valor de cada criptomoeda \xE9 diferente, o valor m\xEDnimo de retirada tamb\xE9m \xE9 diferente</p>\r
  <p>Quanto tempo leva para depositar e sacar?</p>\r
  <p>Cada transa\xE7\xE3o no blockchain requer v\xE1rios ciclos para confirmar que a transfer\xEAncia foi registrada com sucesso.</p>\r
  <p>De um modo geral, cada transa\xE7\xE3o requer de 5 a 10 minutos antes de ser confirmada pela rede blockchain.</p>\r
  <p>Se voc\xEA encontrar algum problema durante o dep\xF3sito ou saque, visite www.blockchain.info para verificar sua transa\xE7\xE3o ou entre em contato com o suporte t\xE9cnico.</p>\r
  <p>Antes de sacar, quantas confirma\xE7\xF5es s\xE3o necess\xE1rias no meu dep\xF3sito?</p>\r
  <p>Para sacar, seu dep\xF3sito total requer pelo menos 3 verifica\xE7\xF5es. Voc\xEA pode verificar as informa\xE7\xF5es atuais do progresso da verifica\xE7\xE3o clicando no link de dep\xF3sito na p\xE1gina do caixa.</p>\r
  <p>De onde v\xEAm as confirma\xE7\xF5es de transa\xE7\xF5es?</p>\r
  <p>Todas as informa\xE7\xF5es de confirma\xE7\xE3o v\xEAm do fornecedor da carteira, do blockchain e dos mineradores.</p>\r
  <p>Quanto tempo demora para confirmar uma transa\xE7\xE3o?</p>\r
  <p>Depende do blockchain e da sua taxa de transfer\xEAncia. Pode demorar 10 minutos ou v\xE1rias horas.</p>\r
  <p>Seu jogo \xE9 justo e justo?</p>\r
  <p>Somos baseados no contrato inteligente Ethereum. Todos os dados e l\xF3gica central no blockchain s\xE3o transparentes e a manipula\xE7\xE3o n\xE3o \xE9 poss\xEDvel. Cada transa\xE7\xE3o no blockchain pode ser rastreada no etherscan. A justi\xE7a, abertura e justi\xE7a da nossa plataforma de jogos s\xE3o garantidas.</p>\r
  <p>O que devo fazer se meu jogo travar ou houver um problema?</p>\r
  <p>Se voc\xEA encontrar algum problema t\xE9cnico ao jogar nossos jogos, tente atualizar o jogo. Normalmente, ele funcionar\xE1 ap\xF3s a atualiza\xE7\xE3o. Caso o problema persista, entre em contato conosco.</p>\r
  <h2>&nbsp;</h2>\r
</section>`,p=`<section>
  <h2>Mulailah Perjalanan Permainan Anda</h2>
  <p>Apakah saya bisa mendaftar di website Anda?</p>
  <p>
    Anda harus berusia minimal 18 tahun atau mencapai usia dewasa di bawah yurisdiksi Anda. Anda harus diizinkan untuk bermain game online oleh undang-undang yang berlaku untuk Anda. Untuk informasi lebih lanjut, silakan baca syarat dan ketentuan kami.
  </p>
  <p>Permainan mungkin membuat ketagihan, dan pemain disarankan untuk mengendalikan diri.</p>
</section>

<section>
  <h2>Informasi Akun</h2>
  <p class="em">1. Bagaimana jika saya lupa kata sandi saya?</p>
  <p>
    Jika Anda lupa kata sandi, Anda dapat mengatur ulang dalam waktu 15 detik melalui tautan \u201CLupa kata sandi\u201D kami. Setelah mengajukan permohonan pengaturan ulang kata sandi, silakan ikuti instruksi dalam email yang kami kirimkan kepada Anda untuk mengatur ulang kata sandi Anda.
  </p>
  <p class="em">
    2. Saya telah kehilangan telepon genggam saya. Bagaimana cara menyetel ulang autentikator Google saya?
  </p>
  <p>
    Jika Anda ingin menghapus Google authenticator 2FA Anda, silakan hubungi kami. Setelah kami menerima aplikasi Anda, demi keamanan akun Anda, Anda diminta untuk menjawab beberapa pertanyaan keamanan dengan benar untuk menghapus 2FA.
  </p>
  <p class="em">3. Dapatkah saya mengubah nama pengguna atau alamat email yang terdaftar?</p>
  <p>
    Maaf, tapi kami tidak bisa memperbarui informasi ini. Jika Anda bersikeras untuk mengubah nama pengguna dan/atau email terdaftar Anda, kami sarankan Anda menutup akun saat ini dan mendaftarkan akun baru.
  </p>
  <p class="em">4. Bagaimana cara saya menjadi VIP?</p>
  <p>
    Klub VIP eksklusif hanya dapat diakses melalui undangan. Setelah Anda memulai perjalanan Anda dalam permainan, Anda akan segera diberi tahu tentang status VIP Anda melalui email.
  </p>
</section>

<section>
  <h2>Dompet Saya</h2>
  <p>
    \u300EDompet Saya\u300F merupakan bagian dari akun pemain. Anda dapat melihat saldo semua mata uang kripto kooperatif, menyetor dan menarik serta menanyakan catatan transaksi. Selanjutnya, Anda juga bisa mendapatkan akses ke BC Swap tanpa peninjauan dan Vault Pro dengan tingkat persentase tahunan (APR) sebesar 5%.
  </p>
</section>

<section>
  <h2>Bagaimana Cara Menyetor?</h2>
  <p>
    1. Cari halaman \u300EDompet saya\u300F, klik halaman deposit, salin alamat dompet, atau pindai kode QR untuk pembayaran.
  </p>
  <p>
    2. Gunakan Dari Alcoin untuk menyetor 150 mata uang kripto yang disediakan oleh Changelly.
  </p>
  <p>3. Setor dan tarik cepat langsung dari penyedia dompet .</p>
  <p>
    <a class="cl-primary" href="/wallet/deposit">Deposit</a>
  </p>
</section>

<section>
  <h2>Apa itu PenukaranBC</h2>
  <p>
    Anda dapat menggunakan Pertukaran BC untuk menukar mata uang kripto tanpa menunggu peninjauan.
  </p>
</section>

<section>
  <h2>Apa itu Vault Pro?</h2>
  <p>
    Ini adalah bank eksklusif BC tempat Anda bisa mendapatkan tingkat persentase tahunan (APR) sebesar 5% dari deposit Anda di Vault Pro.
  </p>
</section>

<section>
  <h2>Bagaimana cara Penarikan?</h2>
  <p>
    Temukan halaman \u300EDompet saya\u300F, buka halaman penarikan, masukkan alamat dompet yang Anda butuhkan untuk menarik dan jumlah mata uang kripto (perhatikan biayanya). Setelah mengklik tombol konfirmasi, mata uang kripto akan ditransfer ke dompet Anda (perhatikan mata uang kripto yang sesuai).
  </p>
  <p>
    <a class="cl-primary" href="/wallet/withdraw">Withdraw</a>
  </p>
</section>

<section>
  <h2>Jumlah Minimum Penarikan</h2>
  <p>
    Karena nilai masing-masing mata uang krypto berbeda, maka jumlah minimum Withdraw juga berbeda.
  </p>
</section>

<section>
  <h2>Berapa lama waktu yang dibutuhkan untuk Penyetoran dan Penarikan?</h2>
  <p>
    Setiap transaksi di blockchain membutuhkan beberapa siklus untuk mengkonfirmasi bahwa transfer telah berhasil dicatat.
  </p>
  <p>
    Secara umum, setiap transaksi memerlukan waktu 5-10 menit sebelum dapat dikonfirmasi oleh jaringan blockchain.
  </p>
  <p>
    Jika Anda mengalami masalah saat melakukan deposit atau Withdraw, Anda dapat mengunjungi
    <a href="https://blockchain.info/">www.blockchain.info</a> untuk memeriksa transaksi Anda, atau hubungi dukungan teknis.
  </p>
</section>

<section>
  <h2>Sebelum Penarikan, berapa banyak konfirmasi yang diperlukan untuk deposit saya?</h2>
  <p>
    Untuk melakukan penarikan, total deposit Anda membutuhkan setidaknya 3 verifikasi. Anda dapat memeriksa informasi kemajuan verifikasi saat ini dengan mengklik tautan setoran di halaman kasir.
  </p>
</section>

<section>
  <h2>Dari mana datangnya konfirmasi transaksi?</h2>
  <p>
    Semua informasi konfirmasi berasal dari pemasok dompet, blockchain, dan penambang.
  </p>
</section>

<section>
  <h2>Berapa lama waktu yang dibutuhkan untuk mengkonfirmasi transaksi?</h2>
  <p>
    Itu tergantung pada blockchain dan biaya transfer Anda. Mungkin perlu waktu 10 menit atau beberapa jam.
  </p>
</section>

<section>
  <h2>Apakah permainan Anda adil?</h2>
  <p>
    Kami didasarkan pada kontrak pintar Ethereum. Semua data dan logika inti pada blockchain bersifat transparan, dan manipulasi tidak mungkin dilakukan. Setiap transaksi tunggal di blockchain dapat dilacak di eterscan. Keadilan, keterbukaan, dan keadilan platform permainan kami dijamin.
  </p>
</section>

<section>
  <h2>Apa yang harus saya lakukan jika permainan saya hang atau ada masalah?</h2>
  <p>
    Jika Anda mengalami masalah teknis saat memainkan game kami, silakan coba untuk menyegarkan game. Biasanya itu akan berfungsi setelah penyegaran. Jika masalah terus berlanjut, silakan hubungi kami.
  </p>
</section>
`;function c(){return o(()=>Promise.resolve({a:1,b:2}),"test"),n(t,{children:[n(r,{children:[a("title",{children:"faq"}),a("meta",{name:"keywords",content:"test"})]}),a(e,{br:s,en:i,id:p})]})}export{c as default};
